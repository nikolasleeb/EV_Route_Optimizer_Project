import os
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PyQt6.QtGui import QPixmap

class AboutWindow(QWidget):
    def __init__(self):
        super(AboutWindow, self).__init__()
        self.initUI()

    def initUI(self):
        mainLayout = QVBoxLayout()
        
        self.insert_title('Nikolas Lee-Bishop', 'icon.nikolas.png', mainLayout)
        text = 'Database design (nikolaslee@vt.edu) '
        self.insert_text(text, mainLayout)

        self.insert_title('Nick Holcomb', 'icon.nick.png', mainLayout)
        text = 'Database design (nickholcomb@vt.edu) '
        self.insert_text(text, mainLayout)

        self.insert_title('John Lynch', 'icon.john.png', mainLayout)
        text = 'Database design (jwlynch4@vt.edu) '
        self.insert_text(text, mainLayout)

        self.insert_title('Ashley Zarb', 'icon.ashley.png', mainLayout)
        text = 'Database design (ashleyzarb18@vt.edu) '
        self.insert_text(text, mainLayout)

        self.insert_title('Ethan Coll', 'icon.ethan.png', mainLayout)
        text = 'Database design (ethancoll2@vt.edu) '
        self.insert_text(text, mainLayout)
        
        mainLayout.addStretch()
        self.setLayout(mainLayout)

    def get_label(self, text, style):
        label = QLabel()
        label.setText(text)
        label.setStyleSheet(style)
        label.setWordWrap(True)
        return label

    def get_image(self, filename):
        filepath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'icons', filename)
        pixmap = QPixmap(filepath)
        label = QLabel()
        label.setPixmap(pixmap.scaled(100, 100))  # Adjust size as needed
        return label

    def insert_title(self, title, image, layout):
        style = "QLabel { color: blue; border-width: 1px; font: bold 20px; }"
        current_layout = QHBoxLayout()
        current_image = self.get_image(image)
        current_label = self.get_label(title, style)
        current_layout.addWidget(current_image)
        current_layout.addWidget(current_label)
        current_layout.addStretch()
        layout.addLayout(current_layout)

    def insert_text(self, text, layout):
        style = "QLabel { color: black; font: 14px; }"
        label = self.get_label(text, style)
        layout.addWidget(label)