from PyQt6.QtWidgets import (QToolBar, QStatusBar)
from PyQt6.QtGui import (QAction, QIcon)
from PyQt6.QtCore import Qt
import os

class MenuToolbar():
    def __init__(self, window):
        self.toolbar = QToolBar('MainToolBar')
        self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)

        self.folder = os.path.dirname(os.path.realpath(__file__)) + '/icons/'

        # Menu, toolbar, statusbar
        self.menu = window.menuBar()
        window.addToolBar(self.toolbar)
        window.setStatusBar(QStatusBar(window))

        # File menu and toolbar buttons
        self.file_menu = self.menu.addMenu('&File')
        self.add_button('&Open', 'Open file', 'icon.open.png',
                        self.file_menu, window, window.dashboard.open_database)       
        self.add_button('&Exit', 'Exit file', 'icon.exit.png',
                        self.file_menu, window, window.dashboard.exit_app)
        
        self.toolbar.addSeparator()
        
        # Data menu and toolbar buttons
        self.data_menu = self.menu.addMenu('&Data')
        self.add_button('&Dash', 'Show dashboard', 'icon.dash.png', 
                        self.data_menu, window, window.dashboard.show_dashboard)
        self.add_button('&Data', 'Show data', 'icon.data.png', 
                        self.data_menu, window, window.dashboard.show_data_window)
        
        self.menu.addSeparator()  # Add a separator after the data menu
        
        # Analyze menu
        self.analyze_menu = self.menu.addMenu('&Analyze')
        self.add_button('&Analyze', 'Analyze data', 'icon.analyze.png', 
                        self.analyze_menu, window, window.dashboard.analyze)
        self.add_button('&Visualize', 'Visualize data', 'icon.visualize.png', 
                        self.analyze_menu, window, window.dashboard.visualize)

        # Help menu and tutorial button
        self.help_menu = self.menu.addMenu('&Help')
        self.add_button('&Tutorial', 'View tutorial', 'icon.tutorial.png',
                        self.help_menu, window, window.dashboard.tutorial)
        
        # Adding About button
        self.add_button('&About', 'About the application', 'icon.about.png',
                        self.help_menu, window, window.dashboard.about)

    # Adds a button to the toolbar and menu
    def add_button(self, text, tip, icon_filename, menu, win, func):
        icon_path = os.path.join(self.folder, icon_filename)
        btn = QAction(QIcon(icon_path), text, win)
        btn.setStatusTip(tip)
        btn.triggered.connect(func)
        self.toolbar.addAction(btn)
        menu.addAction(btn)