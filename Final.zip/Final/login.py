import sys
import sqlite3
import os
from misc import show_message, exit_message
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QWidget, QLineEdit, QPushButton, QLabel, QVBoxLayout, QHBoxLayout

class LoginWindow(QWidget):
    def __init__(self):
        super(LoginWindow, self).__init__()
        self.initUI()

    def initUI(self):
        # User Interface setup
        layout = QVBoxLayout()

        userLabel = QLabel('Username:')
        self.userEditLine = QLineEdit()
        layout.addWidget(userLabel)
        layout.addWidget(self.userEditLine)

        passwordLabel = QLabel('Password:')
        self.passwordEditLine = QLineEdit()
        self.passwordEditLine.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(passwordLabel)
        layout.addWidget(self.passwordEditLine)

        loginButton = QPushButton('Login')
        cancelButton = QPushButton('Cancel')
        loginButton.clicked.connect(self.login_click)
        cancelButton.clicked.connect(self.exit_app)

        buttonLayout = QHBoxLayout()
        buttonLayout.addWidget(loginButton)
        buttonLayout.addWidget(cancelButton)
        layout.addLayout(buttonLayout)

        # Image display
        self.imageLabel = QLabel()
        iconPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'icons', 'icon.login.png')
        pixmap = QPixmap(iconPath)
        self.imageLabel.setPixmap(pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio))
        layout.addWidget(self.imageLabel)

        self.setLayout(layout)

        # Window modal and flags
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setWindowFlags(Qt.WindowType.CustomizeWindowHint)

    def check_username_password(self):
        found = False
        dbPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'users.db')
        con = sqlite3.connect(dbPath)
        cur = con.cursor()
        cur.execute("SELECT * FROM UsersTable")
        data = cur.fetchall()
        user = self.userEditLine.text()
        password = self.passwordEditLine.text()
        for record in data:
            if record[0] == user and record[1] == password:
                found = True
                break
        con.close()
        return found

    def login_click(self):
        if self.check_username_password():
            self.close()
        else:
            self.passwordEditLine.setText('')
            show_message('Username or password cannot be found', 'Login Error')

    def exit_app(self):
        response = exit_message('Are you sure you want to exit the application?', 'Exit App')
        if response:
            sys.exit()