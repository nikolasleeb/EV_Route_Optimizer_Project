import os
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PyQt6.QtGui import QPixmap

class TutorialWindow(QWidget):
    def __init__(self):
        super(TutorialWindow, self).__init__()
        self.initUI()

    def initUI(self):
        mainLayout = QVBoxLayout()
        
        self.insert_title('Open', 'icon.open.png', mainLayout)
        text = 'This button allows you to open existing files from our system. ' + \
               'Clicking it will open a file dialog where you can select a file ' + \
               'to open. This feature supports a variety of file formats, ensuring ' + \
               'you can access and read your documents or images efficiently.'
        self.insert_text(text, mainLayout)

        self.insert_title('Exit', 'icon.exit.png', mainLayout)
        text = 'This button allows you to close the application safely. ' + \
                'Make sure to save all your work before hitting exit to ' + \
                'prevent any loss of data.'
        self.insert_text(text, mainLayout)

        self.insert_title('Dash', 'icon.dash.png', mainLayout)
        text = 'The Dashboard button shows an overview of the entire application, ' + \
                'including stats and quick access to major features.'
        self.insert_text(text, mainLayout)

        self.insert_title('Data', 'icon.data.png', mainLayout)
        text = 'Clicking the Data button will show you all the data stored in ' + \
                'the application, allowing for complex queries and data management tasks.'
        self.insert_text(text, mainLayout)

        self.insert_title('Analyze', 'icon.analyze.png', mainLayout)
        text = 'The Analyze button starts the data analysis module, ' + \
                'where you can apply statistical or machine learning ' + \
                'algorithms to your data to extract insights.'
        self.insert_text(text, mainLayout)

        self.insert_title('Visualize', 'icon.visualize.png', mainLayout)
        text = 'The Visualize button opens the data visualization module, ' + \
                'where you can create charts, graphs, and maps to ' + \
                'represent your data in a visually appealing way.'
        self.insert_text(text, mainLayout)
        
        mainLayout.addStretch()
        self.setLayout(mainLayout)

    def get_label(self, text, style):
        label = QLabel()
        label.setText(text)
        label.setStyleSheet(style)
        label.setWordWrap(True)
        return label

    def get_image(self, filename):
        filepath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'icons', filename)
        pixmap = QPixmap(filepath)
        label = QLabel()
        label.setPixmap(pixmap.scaled(20, 20))
        return label

    def insert_title(self, title, image, layout):
        style = "QLabel { color: blue; border-width: 1px; font: bold 20px; }"
        current_layout = QHBoxLayout()
        current_image = self.get_image(image)
        current_label = self.get_label(title, style)
        current_layout.addWidget(current_image)
        current_layout.addWidget(current_label)
        current_layout.addStretch()
        layout.addLayout(current_layout)

    def insert_text(self, text, layout):
        style = "QLabel { color: black; font: 14px; }"
        label = self.get_label(text, style)
        layout.addWidget(label)