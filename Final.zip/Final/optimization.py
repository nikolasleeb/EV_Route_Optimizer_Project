from scipy.optimize import linprog
import numpy as np
import math

class Optimization:
    def __init__(self, network):
        self.network = network
        self.isStrength = False
        self.nodes = list(self.network.get_nodes())
        self.arcs = list(self.network.get_arcs())
        self.A = None
        self.b = None
        self.c = None
        self.bounds = None
        
    def set_matrices(self):
        # Create a dictionary to map arc names to indices
        arc_index = {arc.name: idx for idx, arc in enumerate(self.arcs)}

        # Initialize A matrix for flow balance constraints
        self.A = np.zeros((len(self.nodes), len(self.arcs)))

        # Fill the A matrix
        for n in self.nodes:
            i = self.nodes.index(n)
            for a in n.outArcList:
                j = arc_index.get(a.name)  # Use get to safely handle missing arcs
                if j is not None:
                    self.A[i][j] = 1
            for a in n.inArcList:
                j = arc_index.get(a.name)  # Use get to safely handle missing arcs
                if j is not None:
                    self.A[i][j] = -1

        # Create objective function and bounds
        self.c = np.zeros(len(self.arcs))
        self.bounds = []
        for a in self.arcs:
            j = arc_index[a.name]
            if self.isStrength:
                self.c[j] = -math.log10(a.weight/(1 + a.weight))
            else:
                self.c[j] = a.weight
            self.bounds.append((0, 1))
            
    # finds shortest or strongest path between origin and destination
    def shortest_path(self, origin, destination):
        path = None
        length = 0
        strength = 1
        
        if origin == destination:
            return path, length, strength
        
        # only b array changes with origin and destination
        self.b = np.zeros(len(self.nodes))
        orig_node = self.network.get_node(origin)
        dest_node = self.network.get_node(destination)
        orig_index = self.nodes.index(orig_node)
        dest_index = self.nodes.index(dest_node)
        self.b[orig_index] = 1
        self.b[dest_index] = -1
        
        # solve model
        res = linprog(self.c, A_eq = self.A, b_eq = self.b, bounds = self.bounds)
        
        # get results
        if res.status == 0:
            path = []
            n = orig_node
            while n.name != destination:
                for a in n.outArcList:
                    j = self.arcs.index(a)
                    if res.x[j] > 0.01:
                        path.append(a)
                        length += a.weight
                        strength *= a.weight / (1 + a.weight)
                        n = a.head
        return path, length, strength