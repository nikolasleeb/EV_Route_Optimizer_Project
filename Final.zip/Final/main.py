import sys
from PyQt6.QtWidgets import (QMainWindow, QApplication,
    QLabel, QVBoxLayout, QHBoxLayout, QWidget, 
    QComboBox, QListWidget, QTreeWidget, QTreeWidgetItem,
    QPushButton, QProgressBar, QColorDialog, QFileDialog,
    QMdiArea, QMdiSubWindow, QMessageBox, QTableWidget, QTableWidgetItem,)


import misc as Misc
from itertools import groupby
import numpy as np1
import pandas as pd
import menutoolbar as mt
import os
from PyQt6.QtCore import Qt
from dashboard import DashboardWindow
from login import LoginWindow

'''
def main():
    app = QApplication(sys.argv)
    main_widget = DashboardWindow()
    main_widget.show()
    sys.exit(app.exec())
'''
class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()
        self.setWindowTitle("EV Route Optimizer")

        self.loginwin = LoginWindow()  # Create the login window
        self.loginwin.show()  # Show the login window

        self.mdi = QMdiArea()
        self.setCentralWidget(self.mdi)

        # Subwindows dictionary
        self.subwindows = {'Dashboard': None, 'data': None, 'tutorial': None, 'about': None, 'visualize': None}

        # Dashboard window
        self.dashboard = DashboardWindow(self)
        self.add_subwindow(self.dashboard, 'Dashboard')
        self.menutoolbar = mt.MenuToolbar(self)
        self.toolbar = self.menutoolbar.toolbar
        self.enable_access(False)

    def add_subwindow(self, window, name):
        if self.subwindows[name]:
            self.subwindows[name].close()
        sub = QMdiSubWindow()
        sub.setWidget(window)
        sub.setWindowFlags(Qt.WindowType.CustomizeWindowHint)
        sub.setWindowTitle(name)
        self.mdi.addSubWindow(sub)
        self.subwindows[name] = sub
        sub.showMaximized()

    def enable_access(self, val):
        self.dashboard.setEnabled(True)
        self.menutoolbar.toolbar.setEnabled(True)
        self.menutoolbar.data_menu.setEnabled(True)
        self.menutoolbar.analyze_menu.setEnabled(True)
app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()