import sys
from PyQt6.QtWidgets import (QMainWindow, QApplication,
QLabel, QVBoxLayout, QHBoxLayout, QWidget, 
QComboBox, QListWidget, QTreeWidget, QTreeWidgetItem,
QPushButton, QProgressBar, QColorDialog, QFileDialog,
QMdiArea, QMdiSubWindow, QMessageBox
) 

import misc as Misc
import os
from itertools import groupby
import numpy as np
from modelview import TableViewWindow
import modelview as mv
import pandas as pd
import database as db
from optimization import Optimization
from network import Network
from PyQt6.QtCore import Qt
from tutorial import TutorialWindow
from about import AboutWindow
from visualize import GraphWindow
from PIL import Image

class DashboardWindow(QWidget):
    def __init__(self, window):
        super().__init__()
        self.mdi_parent = window
        self.database = None

        # Main layout
        mainLayout = QVBoxLayout()

        # Adding ComboBox for Range
        self.rangeLabel = QLabel("Range:")
        self.rangeComboBox = QComboBox()
        rangeLayout = QHBoxLayout()
        rangeLayout.addWidget(self.rangeLabel)
        rangeLayout.addWidget(self.rangeComboBox)
        mainLayout.addLayout(rangeLayout)

        # Adding ComboBox for Origin
        self.originLabel = QLabel("Origin:")
        self.originComboBox = QComboBox()
        originLayout = QHBoxLayout()
        originLayout.addWidget(self.originLabel)
        originLayout.addWidget(self.originComboBox)
        mainLayout.addLayout(originLayout)

        # Adding ComboBox for Destination
        self.destinationLabel = QLabel("Destination:")
        self.destinationComboBox = QComboBox()
        destinationLayout = QHBoxLayout()
        destinationLayout.addWidget(self.destinationLabel)
        destinationLayout.addWidget(self.destinationComboBox)
        mainLayout.addLayout(destinationLayout)

        # Adding TreeWidget for Route
        self.routeLabel = QLabel("Route:")
        self.routeTree = QTreeWidget()
        self.routeTree.setHeaderLabels(['Stop', 'Details'])
        self.routeTree.addTopLevelItem(QTreeWidgetItem(['Stop 1', 'Detail 1']))  
        self.routeTree.addTopLevelItem(QTreeWidgetItem(['Stop 2', 'Detail 2']))  
        routeLayout = QVBoxLayout()
        routeLayout.addWidget(self.routeLabel)
        routeLayout.addWidget(self.routeTree)
        mainLayout.addLayout(routeLayout)

        # Adding Button for Analysis
        self.analyzeButton = QPushButton("Analyze")
        self.analyzeButton.clicked.connect(self.analyze)
        analyzeLayout = QHBoxLayout()
        analyzeLayout.addStretch()
        analyzeLayout.addWidget(self.analyzeButton)
        analyzeLayout.addStretch()
        mainLayout.addLayout(analyzeLayout)

        # Set the main layout
        self.setLayout(mainLayout)

    # open database
    def open_database(self):
        fname, ok = QFileDialog.getOpenFileName(self, 'Open file',
                                                os.path.dirname(os.path.realpath(__file__)),
                                                'Sqlite3 database files (*.db)')
        if fname:
            self.mdi_parent.enable_access(True)
            self.database = db.Database(fname)
            self.initalize_dashboard()
        else:
            QMessageBox.warning(self, "Database Not Loaded", "Please load a database before attempting to view data.")

    # show data
    def show_data_window(self):
        if self.database is not None:
            data, fields = self.database.get_data()
            data = pd.DataFrame(data, columns=fields)
            win = TableViewWindow(data, 'Data View')
            self.mdi_parent.add_subwindow(win, 'data')
        else:
            QMessageBox.warning(self, "Database Not Loaded", "Please load a database before attempting to view data.")

    # exit
    def exit_app(self):
        response = QMessageBox.question(self, 'Exit App', 'Are you sure you want to exit?',
                                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                        QMessageBox.StandardButton.No)
        if response == QMessageBox.StandardButton.Yes:
            sys.exit()

    # show dashboard
    def show_dashboard(self):
        self.mdi_parent.dashboard.showMaximized()

    # initialize
    def initalize_dashboard(self):
        self.data, self.fields = self.database.get_data()
        self.network = Network(self.database)

        self.rangeComboBox.addItems([str(x * 100) for x in range(1, 4)])

        origin_names = sorted(self.network.get_node_names())
        self.originComboBox.addItems(origin_names)
        self.originComboBox.setCurrentIndex(0)

        dest_names = sorted(self.network.get_node_names())
        self.destinationComboBox.addItems(dest_names)
        self.destinationComboBox.setCurrentIndex(1)

    # analyze
    def analyze(self):
        self.show_dashboard()

        # Initialize properties
        self.stops = []
        self.edge_list = []

        origin = self.originComboBox.currentText()
        dest = self.destinationComboBox.currentText()
        model = Optimization(self.network)
        model.set_matrices()
        path, length, strength = model.shortest_path(origin, dest)
        range = float(self.rangeComboBox.currentText())
        self.routeTree.clear()

        for arc in path:
            info = '{0}: {1:.0f}'.format(arc.name, arc.weight * 70)
            self.edge_list.append(arc)  # Store the path as an edge list

            if range < arc.weight * 70:
                info += ' ***(Recharge)'
                range = float(self.rangeComboBox.currentText())
                self.stops.append(arc.tail.name)  # Append stop for recharging

            else:
                range -= arc.weight * 70

            arc_item = QTreeWidgetItem()
            arc_item.setText(0, info)
            self.routeTree.addTopLevelItem(arc_item)

    def tutorial(self):
        # Create a tutorial window 
        if not self.mdi_parent.subwindows['tutorial']:
            window = TutorialWindow()
            self.mdi_parent.add_subwindow(window, 'tutorial')
        else:
            self.mdi_parent.subwindows['tutorial'].setFocus()

    def about(self):
        # Create an About Window
        if not self.mdi_parent.subwindows['about']:
            window = AboutWindow()
            self.mdi_parent.add_subwindow(window, 'about')
        else:
            self.mdi_parent.subwindows['about'].setFocus()

    def visualize(self):
        origin = self.originComboBox.currentText()
        last_edge = self.edge_list[-1]
        destination = last_edge.head.name
        image = 'icons/virginia.map.png'
        node_ids = [item[0] for item in self.data]
        node_colors = ['gray' for _ in self.data]
        
        i = node_ids.index(origin)
        node_colors[i] = 'red'

        j = node_ids.index(destination)
        node_colors[i] = 'blue'

        for stop in self.stops:
            j = node_ids.index(stop)
            node_colors[j] = 'orange'
        
        positions = []
        width, height = Image.open(image).size
        
        for data in self.data:
            xcoord = data[1] / width
            ycoord = data[2] / height
            positions.append((xcoord, ycoord))
        
        node_size = 0.02
        sizes = [node_size for _ in self.data]
        arc_list = self.network.get_arcs()
        edges = [(arc.tail.name, arc.head.name) for arc in arc_list]
        edge_names = [arc.edgeName for arc in arc_list]
        edge_colors = ['black' for _ in arc_list]
        weights = [1 for _ in arc_list]

        for arc in self.edge_list:
            i = edge_names.index(arc.edgeName)
            edge_colors[i] = 'red'
            weights[i] = 5

        edge_values = ['{0:.0f}'.format(arc.weight) for arc in arc_list]
        window = GraphWindow(node_ids, node_colors, positions, sizes, edges, edge_colors, weights, edge_values, image)
        self.mdi_parent.add_subwindow(window, 'visualize')