import sqlite3

class Database:

    def __init__(self, fname):
        if fname:
            self.fname = fname
        else:
            return None
  
    # return all information from Arcs table as network data
    def get_data(self):
        con = sqlite3.connect(self.fname)
        cur = con.cursor()
        res = cur.execute("SELECT * FROM locations")
        data = res.fetchall()
        fields = [x[0] for x in cur.description]
        return data, fields